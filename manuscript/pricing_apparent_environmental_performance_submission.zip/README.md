# Submission package — Risk Analysis

- manuscript_blinded.docx/.pdf: double-blind manuscript, title-only first page,
  figures and tables inline.
- manuscript_text.docx/.pdf: text-only manuscript with figure legends.
- title_page.docx: separate title page (article type: Original Research).
- cover_letter.docx/.pdf, declarations.md: cover letter and declarations with
  author-action placeholders.
- supplement.docx/.pdf: supplementary material (Tables S1–S6).
- figures/: journal figure files (vector PDF + 600-dpi PNG).
- tables/: main tables as CSV.
- figures_editable.pptx, tables/*_editable.docx: editable figure/table decks.
- AUTHOR_ACTIONS_REQUIRED.md, RISK_ANALYSIS_COMPLIANCE_CHECKLIST.md, and
  FINAL_RISK_ANALYSIS_REPORT.md are included for the author's records, not
  for upload.
