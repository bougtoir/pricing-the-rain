# Submission package — Journal of Economic Behavior & Organization

- manuscript_blinded.docx/.pdf: manuscript without author identification on the
  title line, figures and tables inline (JEBO review is single-anonymized; the
  title page is submitted separately).
- manuscript_text.docx/.pdf: text-only manuscript with figure legends.
- title_page.docx: separate title page (article type: Research article).
- cover_letter.docx/.pdf, declarations.md: cover letter and declarations with
  author-action placeholders.
- supplement.docx/.pdf: supplementary material (Tables S1–S10, Figures S1–S3).
- figures/: journal figure files (vector PDF + 600-dpi PNG).
- tables/: main tables as CSV.
- figures_editable.pptx, tables/*_editable.docx: editable figure/table decks.
- AUTHOR_ACTIONS_REQUIRED.md, JEBO_COMPLIANCE_CHECKLIST.md,
  and the audit/revision/decision docs are included for the author's
  records, not for upload.
- The current reports are the JEBO_* docs (compliance checklist, citation
  ecology, retargeting report, hostile review report, numeric hard-code
  audit, public reproducibility audit, result traceability, data-text-figure
  consistency, citation audit, final submission audit). QREF_*, FINAL_* and
  ECONOMIC_MODELLING_* reports are superseded and retained only for
  provenance.
