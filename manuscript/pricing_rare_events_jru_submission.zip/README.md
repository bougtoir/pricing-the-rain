# Submission package — Journal of Risk and Uncertainty

- manuscript_blinded.docx/.pdf: manuscript without author identification,
  figures (Fig. 1–8) and tables placed in the text; the title page is a
  separate file.
- manuscript_text.docx/.pdf: text-only manuscript with figure captions.
- title_page.docx: title page (article type, authors, affiliations,
  corresponding author, ORCID, JEL codes).
- cover_letter.docx/.pdf, declarations.md: cover letter and Statements and
  Declarations with author-action placeholders.
- supplement.docx/.pdf: Online Resource 1 (Tables S1–S10).
- figures/: figure files (vector PDF + 600-dpi PNG).
- tables/: main tables as CSV; tables/*_editable.docx and
  figures_editable.pptx are editable versions.
- AUTHOR_ACTIONS_REQUIRED.md and the JRU_* audit reports are for the
  author's records, not for upload. JEBO_*, QREF_*, FINAL_* and
  ECONOMIC_MODELLING_* reports are superseded and kept for provenance.
