# Submission package — The Quarterly Review of Economics and Finance

- manuscript_blinded.docx/.pdf: double-blind manuscript, title-only first page,
  figures and tables inline.
- manuscript_text.docx/.pdf: text-only manuscript with figure legends.
- title_page.docx: separate title page (article type: Research article).
- cover_letter.docx/.pdf, declarations.md: cover letter and declarations with
  author-action placeholders.
- supplement.docx/.pdf: supplementary material (Tables S1–S10, Figures S1–S3).
- figures/: journal figure files (vector PDF + 600-dpi PNG).
- tables/: main tables as CSV.
- figures_editable.pptx, tables/*_editable.docx: editable figure/table decks.
- AUTHOR_ACTIONS_REQUIRED.md, QREF_COMPLIANCE_CHECKLIST.md,
  and the audit/revision/decision docs are included for the author's
  records, not for upload.
- The current reports are the QREF_* docs (compliance checklist, citation
  ecology, retargeting report, hostile review report, numeric hard-code
  audit, final retargeting audit). Earlier FINAL_* and
  ECONOMIC_MODELLING_* reports are superseded and retained only for
  provenance; ARCHIVED_PRE_TARGETED_REVISION_REPORT.md is likewise
  superseded provenance.
