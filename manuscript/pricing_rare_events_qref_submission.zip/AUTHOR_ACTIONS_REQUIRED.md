# Author actions required before submission (Quarterly Review of Economics and Finance)

The scientific and reproducibility package may be finalized while these items remain
open, but the manuscript must not be submitted until the responsible author supplies
or confirms each item.

1. Confirm author names, order, affiliations, correspondence address, email, telephone
   number, and ORCIDs where applicable. (QREF uses double-anonymized review: keep all
   of this on the separate title page and in the submission system only — the blinded
   manuscript must carry no names or affiliations.)
2. Provide acknowledgements or explicitly confirm that none are required.
3. Identify all funding sources and grant numbers, or confirm that no specific funding
   supported the work.
4. Provide the competing-interests declaration.
5. Assign CRediT roles to every author.
6. Confirm originality and exclusive submission (a submission is a representation that
   the work is not under consideration elsewhere).
7. Confirm that every author approved the final manuscript and submission.
8. Review the generative-AI disclosure (Elsevier policy wording, currently in the
   Declarations section) and confirm final human review, editing, and responsibility.
9. **Submission fee:** QREF levies a US$150 non-refundable submission fee for new,
   unsolicited manuscripts, payable in the submission system before the manuscript is
   considered. This is a mandatory fee distinct from any optional open-access charge —
   the author must decide whether to pay it.
10. In the QREF submission system (Elsevier Editorial Manager): select "Research
    article", upload the blinded manuscript, separate title page, figure files
    (PDF/PNG acceptable), supplementary material, the data/code availability
    statement, and confirm the checklist responses. Elsevier also asks for a
    highlights file and suggested reviewers — prepare both in the system.
    JEL classification codes are already on the manuscript (D81, D82, D83, D84);
    confirm or adjust them in the system metadata.
11. Review the cover letter, select any suggested or opposed reviewers, decide the
    optional open-access (APC) choice — subscription publication carries no fee —
    and approve the journal-generated submission PDF.

Author-specific information must replace the bracketed placeholders in the title page,
manuscript declarations, cover letter, and submission system.
